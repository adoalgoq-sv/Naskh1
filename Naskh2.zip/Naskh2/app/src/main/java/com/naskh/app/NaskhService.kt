package com.naskh.app

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class NaskhService : AccessibilityService() {

    companion object {
        const val ACTION_CAPTURE = "com.naskh.app.CAPTURE"
        private const val CHANNEL = "naskh"
    }

    private val main = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var busy = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == ACTION_CAPTURE) main.postDelayed({ capture() }, 500)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(ACTION_CAPTURE), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        showNotification()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        removeOverlay()
        super.onDestroy()
    }

    private fun showNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "ناسخ", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getBroadcast(
            this, 1, Intent(ACTION_CAPTURE).setPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("ناسخ")
            .setContentText("اضغط «نسخ» لتحديد النص")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_crop, "نسخ", pi).build())
            .build()
        nm.notify(1, n)
    }

    private fun capture() {
        if (overlay != null || busy) return
        busy = true
        val boxes = ArrayList<Box>()
        val root = rootInActiveWindow
        if (root != null) walk(root, boxes)

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    busy = false
                    if (bmp != null) showOverlay(bmp, boxes) else toast("تعذر التقاط الشاشة")
                }

                override fun onFailure(errorCode: Int) {
                    busy = false
                    toast("تعذر التقاط الشاشة")
                }
            }
        )
    }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<Box>) {
        if (n == null) return
        if (n.isVisibleToUser) {
            val t = (n.text ?: n.contentDescription)?.toString()
            if (!t.isNullOrBlank()) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) out.add(Box(r, t))
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), out)
    }

    private fun showOverlay(bmp: Bitmap, boxes: List<Box>) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val pick = PickView(this, bmp, boxes)

        fun btn(label: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { onClick() }
            return b
        }

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.setBackgroundColor(0xDD000000.toInt())
        bar.setPadding(16, 16, 16, 120)
        val w = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        bar.addView(btn("نسخ المحدد") { doCopy(pick, false) }, w)
        bar.addView(btn("نسخ الكل") { doCopy(pick, true) }, w)
        bar.addView(btn("إغلاق") { removeOverlay() }, w)

        val frame = FrameLayout(this)
        frame.addView(pick, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        frame.addView(bar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(frame, lp)
        overlay = frame
        toast(if (boxes.isEmpty()) "ما لقيت نصوص، اسحب على المنطقة لقراءتها" else "اضغط على النص أو اسحب لتحديده")
    }

    private fun doCopy(pick: PickView, all: Boolean) {
        val text = if (all) pick.allText() else pick.selectedText()
        if (text.isNotBlank()) {
            setClip(text)
            removeOverlay()
            return
        }
        val crop = if (all) null else pick.crop()
        if (crop == null) {
            toast(if (all) "ما لقيت نص بالشاشة" else "حدد نصًا أولًا")
            return
        }
        removeOverlay()
        toast("جاري القراءة...")
        thread {
            val t = runCatching { Ocr.read(this, crop) }.getOrDefault("")
            main.post { if (t.isBlank()) toast("ما لقيت نص") else setClip(t) }
        }
    }

    private fun setClip(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("naskh", text))
        toast("تم النسخ")
    }

    private fun removeOverlay() {
        val v = overlay ?: return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        runCatching { wm.removeView(v) }
        overlay = null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
