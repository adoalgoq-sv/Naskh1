package com.naskh.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

data class Box(val rect: Rect, val text: String)

/** Frozen screenshot with a box around every text on screen. Tap a box or drag over boxes to select. */
class PickView(
    ctx: Context,
    private val shot: Bitmap,
    private val boxes: List<Box>
) : View(ctx) {

    private val selected = HashSet<Int>()
    private var dragRect: RectF? = null
    private var sx = 0f
    private var sy = 0f
    private var cx = 0f
    private var cy = 0f

    private val outline = Paint().apply {
        color = 0xFF2196F3.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = true
    }
    private val fill = Paint().apply { color = 0x6600E676; style = Paint.Style.FILL }
    private val dragPaint = Paint().apply {
        color = 0xFFFF9800.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true
    }

    private fun kx() = width.toFloat() / shot.width
    private fun ky() = height.toFloat() / shot.height

    private fun viewRect(b: Box): RectF =
        RectF(b.rect.left * kx(), b.rect.top * ky(), b.rect.right * kx(), b.rect.bottom * ky())

    override fun onDraw(c: Canvas) {
        c.drawBitmap(shot, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), null)
        for ((i, b) in boxes.withIndex()) {
            val r = viewRect(b)
            if (selected.contains(i)) c.drawRect(r, fill)
            c.drawRect(r, outline)
        }
        dragRect?.let { c.drawRect(it, dragPaint) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y; cx = e.x; cy = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                cx = e.x; cy = e.y
                dragRect = RectF(minOf(sx, cx), minOf(sy, cy), maxOf(sx, cx), maxOf(sy, cy))
            }
            MotionEvent.ACTION_UP -> {
                val dist = Math.hypot((cx - sx).toDouble(), (cy - sy).toDouble())
                if (dist < 25) {
                    dragRect = null
                    toggleAt(e.x, e.y)
                } else {
                    val r = dragRect
                    if (r != null) {
                        var hit = false
                        for ((i, b) in boxes.withIndex()) {
                            if (RectF.intersects(r, viewRect(b))) { selected.add(i); hit = true }
                        }
                        if (hit) dragRect = null
                    }
                }
            }
        }
        invalidate()
        return true
    }

    private fun toggleAt(x: Float, y: Float) {
        var best = -1
        var bestArea = Float.MAX_VALUE
        for ((i, b) in boxes.withIndex()) {
            val r = viewRect(b)
            if (r.contains(x, y)) {
                val a = r.width() * r.height()
                if (a < bestArea) { best = i; bestArea = a }
            }
        }
        if (best >= 0) {
            if (selected.contains(best)) selected.remove(best) else selected.add(best)
        }
    }

    private fun join(list: List<Box>): String =
        list.sortedWith(compareBy<Box>({ it.rect.top }, { it.rect.left })).joinToString("\n") { it.text }

    fun selectedText(): String = join(boxes.filterIndexed { i, _ -> selected.contains(i) })

    fun allText(): String = join(boxes)

    /** Region dragged by the user (used for OCR when no text boxes were hit). */
    fun crop(): Bitmap? {
        val r = dragRect ?: return null
        val fx = shot.width.toFloat() / width
        val fy = shot.height.toFloat() / height
        val l = (r.left * fx).toInt().coerceIn(0, shot.width - 1)
        val t = (r.top * fy).toInt().coerceIn(0, shot.height - 1)
        val w = (r.width() * fx).toInt().coerceIn(1, shot.width - l)
        val h = (r.height() * fy).toInt().coerceIn(1, shot.height - t)
        return Bitmap.createBitmap(shot, l, t, w, h)
    }
}
